Clifford:
a lightweight package for performing Geometric and Clifford Algebra calculations

	version 2.3.2 Date 30 July 2016
	 - bugfix release: regressions in tellsimpafter
	 - demos extended
	  
	2.3 Date 02 July 2016
	- bugfix release
	- bugfixes in  clicoeff
	
	2.2 Date 20 June 2016	  
    - new definitions of inner and outer products 
	- changes in cinvolve
	
	2.1 Date 12 May 2016
	- refactoring
	- linear algebra functionality separated
	- matrix representations
 
	2.0 Date 10 Apr 2016
	- new definitions of  inner product and  outer product (wrong)
	- bug fiix in clicoeff
	
	1.9 Date 16 Feb 2016
	- bug fix in simplification
	- change in factorby, reflect
	
	1.8 Date 06 Dec 2015
	- change of notation to exclude conflicts with itensor-based packages
	
	1.7 Date 18 Nov 2015
    - refactoring
	- change in grade
	- chage in simp rules

	1.6 Date 04 Nov 2015
	- bugixes oppart
	- unit tests

	1.5.1 Date 30 Oct 2015
	- bugfixes oppart
	- unit tests

	1.4 Date 22 Aug 2015
	- oppart simplified
	- unit tests

	1.3 Date 11 Jun 2015
	- unit tests
	
	1.0 Date 26 Jan 2015
	- initial implementation
	- GitHub repo created
	
**********************************
 **License**

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Zenodo:
http://dx.doi.org/10.5281/zenodo.61261
